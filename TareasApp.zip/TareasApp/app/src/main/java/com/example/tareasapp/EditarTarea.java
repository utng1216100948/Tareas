package com.example.tareasapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.tareasapp.dao.TareaDAO;
import com.example.tareasapp.model.Tarea;

public class EditarTarea extends AppCompatActivity {

    private EditText edtCveTarea;
    private EditText edtDescripcion;
    Spinner spnPrioridad;
    Spinner spnEstatus;
    private EditText edtFechaCompromiso;
    private Button btnActualizar;
    private Button btnCancelar;
    private Button btnEliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_tarea);
        //Inflate
        edtCveTarea = (EditText) findViewById(R.id.edt_cveTarea3);
        edtDescripcion = (EditText) findViewById(R.id.edt_descripcion3);
        edtFechaCompromiso = (EditText) findViewById(R.id.edt_fecha3);

        spnPrioridad = (Spinner) findViewById(R.id.spn_prioridadE3);
        ArrayAdapter<CharSequence> adapterSpnPrioridad = ArrayAdapter.createFromResource(this,
                R.array.prioridad, android.R.layout.simple_spinner_item);
        spnPrioridad.setAdapter(adapterSpnPrioridad);
        spnEstatus = (Spinner) findViewById(R.id.spn_estatusE3);
        ArrayAdapter<CharSequence> adapterSpnEstatus = ArrayAdapter.createFromResource(this,
                R.array.estatus, android.R.layout.simple_spinner_item);
        spnEstatus.setAdapter(adapterSpnEstatus);

        btnActualizar = (Button) findViewById(R.id.btn_actualizar);
        btnCancelar = (Button) findViewById(R.id.btn_cancelar);
        btnEliminar = (Button) findViewById(R.id.btn_eliminar);
        //Se obtiene el valor del código
        String clave = getIntent().getExtras().getString("cveTarea");
        //Se crea un objeto Tarea
        Tarea t = new Tarea();
        //Se asigna el código a la tarea
        t.setCveTarea(clave);
        //Se crea un objeto DAO
        TareaDAO dao = new TareaDAO(getApplicationContext());
        try {
            t = dao.getById(t);
            //En caso de exito asignamos los valores a los conroles
            edtCveTarea.setText(t.getCveTarea());
            edtDescripcion.setText(t.getDescripcion());
            spnPrioridad.setSelected(Boolean.parseBoolean(t.getPrioridad()));
            edtFechaCompromiso.setText(t.getFechaCompromiso());
            spnEstatus.setSelected(Boolean.parseBoolean(t.getEstatus()));
        }catch(Exception e){
            //En caso de error
            Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }

        //Se agrega escuchador al boton actualizar
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tarea t = new Tarea();
                //Se asignan los datos a los atributos de objeto
                t.setCveTarea(edtCveTarea.getText().toString());
                t.setDescripcion(edtDescripcion.getText().toString());
                t.setPrioridad(spnPrioridad.getSelectedItem().toString());
                t.setFechaCompromiso(edtFechaCompromiso.getText().toString());
                t.setEstatus(spnEstatus.getSelectedItem().toString());
                //Se crea un objeto DAO para almacenar al objeto
                TareaDAO dao = new TareaDAO(getApplicationContext());
                //Se intenta realizar los cambios
                try {
                    dao.updateTarea(t);
                    Toast.makeText(getApplicationContext(), "Tarea actualizado!",Toast.LENGTH_SHORT).show();
                    //Se cierra el activity
                    System.exit(0);
                }catch(Exception e){
                    //Se manda mensaje en caso de error
                    Toast.makeText(getApplicationContext(),"Error: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });
        //Se agrega un escuchador de eventos al boton btnEliminar
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tarea t = new Tarea();
                t.setCveTarea(edtCveTarea.getText().toString());
                TareaDAO dao = new TareaDAO(getApplicationContext());
                //Se intenta eliminar el objeto
                try {
                    dao.deleteTarea(t);
                    //Mensaje de exito
                    Toast.makeText(getApplicationContext(),"Producto Eliminado!",Toast.LENGTH_LONG).show();
                    //Se cierra el activity
                    System.exit(0);
                }catch(Exception e){
                    //Se manda mensaje en caso de error
                    Toast.makeText(getApplicationContext(),"Error: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });
        //Se asigna un escuchador al botob btnCancelar
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Se cierra la vista
                System.exit(0);
            }
        });
    }
}/*End*/