package com.example.tareasapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.tareasapp.dao.TareaDAO;
import com.example.tareasapp.model.Tarea;

public class NuevaTarea extends AppCompatActivity {

    private EditText edtCveTarea;
    private EditText edtDescripcion;
    Spinner spnPrioridad;
    Spinner spnEstatus;
    private EditText edtFechaCompromiso;
    private Button btnGuardar;
    private Button btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_tarea);
        //Inflate
        edtCveTarea = (EditText) findViewById(R.id.edt_cveTarea);
        edtDescripcion = (EditText) findViewById(R.id.edt_descripcion);
        edtFechaCompromiso = (EditText) findViewById(R.id.edt_fecha);
        //First Spinner
        spnPrioridad = (Spinner) findViewById(R.id.spn_prioridad);
        ArrayAdapter<CharSequence> adapterSpnPrioridad = ArrayAdapter.createFromResource(this,
                R.array.prioridad, android.R.layout.simple_spinner_item);
        spnPrioridad.setAdapter(adapterSpnPrioridad);
        //Second Spinner
        spnEstatus = (Spinner) findViewById(R.id.spn_estatus);
        ArrayAdapter<CharSequence> adapterSpnEstatus = ArrayAdapter.createFromResource(this,
                R.array.estatus, android.R.layout.simple_spinner_item);
        spnEstatus.setAdapter(adapterSpnEstatus);

        btnGuardar = (Button) findViewById(R.id.btn_guardar);
        btnCancelar = (Button) findViewById(R.id.btn_cancelar);

        /* SE AGREGA ESCUCHADOR PARA BOTON GUARDAR */
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tarea t = new Tarea();
                //Se asignan los atributos
                t.setCveTarea(edtCveTarea.getText().toString());
                t.setDescripcion(edtDescripcion.getText().toString());
                t.setPrioridad(spnPrioridad.getSelectedItem().toString());
                t.setFechaCompromiso(edtFechaCompromiso.getText().toString());
                t.setEstatus(spnEstatus.getSelectedItem().toString());
                //Se crea un objeto DAO
                TareaDAO dao = new TareaDAO(getApplicationContext());
                //Se intenta insertar el objeto
                try {
                    dao.insertarTarea(t);
                    //Se manda mensaje de exito
                    Toast.makeText(getApplicationContext(), "La tarea ha sido registrada!", Toast.LENGTH_SHORT).show();
                    limpiarRegistro();
                }catch (Exception e){
                    //Se muestra mensaje de error
                    Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
                    //Se cierra el activity
                    System.exit(0);
                }
                limpiarRegistro();
            }
        });

        /* SE AGREGA ESCUCHADOR PARA BOTON CANCELAR */
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limpiarRegistro();
                //Se cierra el activity
                System.exit(0);
                Toast.makeText(getApplicationContext(), "Cancelando...", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void limpiarRegistro() {
        edtCveTarea.setText("");
        edtDescripcion.setText("");
        spnPrioridad.setSelection(0);
        edtFechaCompromiso.setText("");
        spnEstatus.setSelection(0);
    }
}/*End*/