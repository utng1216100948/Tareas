package com.example.tareasapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.tareasapp.dao.Conexion;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btnNuevaTarea;
    private Button btnVerTareas;
    private Button btnInicializeBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Relacionar los objetos del xml con la clase JAVA
        btnNuevaTarea = (Button) findViewById(R.id.btn_nuevaTarea);
        btnVerTareas = (Button) findViewById(R.id.btn_verTareas);
        btnInicializeBD = (Button) findViewById(R.id.btn_inicializarBD);
        //Registrar el escuchador
        btnNuevaTarea.setOnClickListener(this);
        btnVerTareas.setOnClickListener(this);
        btnInicializeBD.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_nuevaTarea){
            Intent intentNew = new Intent(getApplicationContext(),NuevaTarea.class);
            startActivity(intentNew);
        }else if(v.getId() == R.id.btn_verTareas){
            Intent intentView = new Intent(getApplicationContext(), ListaTareas.class);
            startActivity(intentView);
        }else if(v.getId() == R.id.btn_inicializarBD){
            try {
                Conexion conexion= new Conexion(getApplicationContext());
                conexion.inicializarBD();
                //Mensaje de conexión exiosa
                Toast.makeText(getApplicationContext(),"BD Conneted", Toast.LENGTH_SHORT).show();
            }catch(Exception e) {
                //Mensaje de error de conexión
                Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}/*End*/