package com.example.tareasapp.dao;

import android.content.Context;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.tareasapp.R;
import com.example.tareasapp.model.Tarea;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TareaDAO {
    private Context context;

    public TareaDAO(Context context){
        this.context = context;
    }

    public void insertarTarea(Tarea obj) throws Exception{
        String comando = "INSERT INTO TAREAS(cveTarea, descripcion, prioridad, fechaCompromiso, estatus) " +
                "VALUES ('"+obj.getCveTarea()+"','"+obj.getDescripcion()+"','"+obj.getPrioridad()+"','"+obj.getFechaCompromiso()+"','"+obj.getEstatus()+"')";

        Conexion con= new Conexion(context);
        try{
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw  new Exception("Error al insertar: "+ e.getMessage());
        }
    }

    public void updateTarea(Tarea obj) throws Exception{
        String comando = "UPDATE TAREAS SET cveTarea='"+obj.getCveTarea()+"',descripcion='"+obj.getDescripcion()+"',prioridad='"+obj.getPrioridad()+"',fechaCompromiso='"+obj.getFechaCompromiso()+"',estatus='"+obj.getEstatus()+"' "+ " WHERE cveTarea='"+obj.getCveTarea()+"'";

        Conexion con = new Conexion(context);
        try {
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw  new Exception("Errot al actualizar: "+ e.getMessage());
        }
    }

    public void deleteTarea(Tarea obj) throws Exception{
        String comando = "DELETE FROM TAREAS WHERE cveTarea='"+obj.getCveTarea()+"'";

        Conexion con= new Conexion(context);
        try {
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw new Exception("Error al eliminar: "+ e.getMessage());
        }
    }

    public List<Tarea> getAll() throws Exception{
        String tabla = "TAREAS";
        String campos [] = new String[]{"cveTarea","descripcion","prioridad","fechaCompromiso","estatus"};

        List<Tarea> listaTareas = new ArrayList<Tarea>();
        Conexion con = new Conexion(context);

        List<HashMap<String,String>> resultado;
        resultado= con.ejecutarConsulta(tabla, campos, null);

        Tarea tarea;

        for (HashMap<String, String> reg: resultado){
            tarea = new Tarea();

            tarea.setCveTarea(reg.get("cveTarea"));
            tarea.setDescripcion(reg.get("descripcion"));
            tarea.setPrioridad(reg.get("prioridad"));
            tarea.setFechaCompromiso(reg.get("fechaCompromiso"));
            tarea.setEstatus(reg.get("estatus"));

            listaTareas.add(tarea);
        }
        return listaTareas;
    }

    public Tarea getById(Tarea obj) throws Exception{
        String tabla = "TAREAS";
        String campos [] = new String[]{"cveTarea","descripcion","prioridad","fechaCompromiso","estatus"};

        String condicion = "cveTarea='"+obj.getCveTarea()+"'";

        Conexion con = new Conexion(context);
        List<HashMap<String,String>> resultado;
        resultado= con.ejecutarConsulta(tabla, campos, condicion);

        Tarea tarea = null;

        for (HashMap<String, String> reg: resultado){
            tarea = new Tarea();

            tarea.setCveTarea(reg.get("cveTarea"));
            tarea.setDescripcion(reg.get("descripcion"));
            tarea.setPrioridad(reg.get("prioridad"));
            tarea.setFechaCompromiso(reg.get("fechaCompromiso"));
            tarea.setEstatus(reg.get("estatus"));
        }
        return tarea;
    }
}/* End */