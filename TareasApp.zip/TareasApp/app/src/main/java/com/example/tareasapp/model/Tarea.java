package com.example.tareasapp.model;

public class Tarea {

    //Atributos de la clase
    private String cveTarea;
    private String descripcion;
    private String prioridad;
    private String fechaCompromiso;
    private String estatus;

    public Tarea(String cveTarea, String descripcion, String prioridad, String fechaCompromiso, String estatus) {
        this.cveTarea = cveTarea;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.fechaCompromiso = fechaCompromiso;
        this.estatus = estatus;
    }

    public Tarea() {
    }

    public String getCveTarea() {
        return cveTarea;
    }

    public void setCveTarea(String cveTarea) {
        this.cveTarea = cveTarea;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getFechaCompromiso() {
        return fechaCompromiso;
    }

    public void setFechaCompromiso(String fechaCompromiso) {
        this.fechaCompromiso = fechaCompromiso;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    @Override
    public String toString() {
        return "Tarea{" +
                "cveTarea='" + cveTarea + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", prioridad='" + prioridad + '\'' +
                ", fechaCompromiso='" + fechaCompromiso + '\'' +
                ", estatus='" + estatus + '\'' +
                '}';
    }
}/* End */