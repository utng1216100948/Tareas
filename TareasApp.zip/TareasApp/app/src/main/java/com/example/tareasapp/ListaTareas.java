package com.example.tareasapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tareasapp.dao.TareaDAO;
import com.example.tareasapp.model.Tarea;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ListaTareas extends AppCompatActivity {

    private ListView lsvTareas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_tareas);
        //Inflate
        lsvTareas = (ListView) findViewById(R.id.lsv_tareas);

        //Se crea objeto dao para consultar las tareas
        TareaDAO dao = new TareaDAO(getApplicationContext());
        //Se crea objeto para la lista de tareas y se obtiene el objeto
        List<Tarea> listaTareas;
        try {
            //Se realiza la consulta
            listaTareas = dao.getAll();
            //Se crea un objeto hashMap para cada registro
            List<HashMap<String, String>> filas = new ArrayList<HashMap<String, String>>();
            HashMap<String,String> registro;
            for(Tarea tar: listaTareas){
                registro = new HashMap<String, String>();
                registro.put("cveTarea", tar.getCveTarea());
                registro.put("descripcion", tar.getDescripcion());
                registro.put("prioridad", tar.getPrioridad());
                registro.put("fechaCompromiso", tar.getFechaCompromiso());
                registro.put("estatus", tar.getEstatus());

                filas.add(registro);
            }
            //Se crea un adaptador para visualizar el registro de la lista
            SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(), filas, R.layout.activity_registro_tarea, new String[]{"cveTarea",
            "descripcion","prioridad","fechaCompromiso","estatus"}, new int[]{R.id.edt_cveTarea2, R.id.edt_descripcion2, R.id.spn_prioridad2, R.id.edt_fecha2, R.id.spn_estatus2});
            //Se asigna el adaptador a la vista
            lsvTareas.setAdapter(adapter);

            //Se genera un escuchador de eventos para los items del ListView
            lsvTareas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    //Se obtiene el código del elemento seleccionado
                    TextView edtCveTarea = (TextView)arg1.findViewById(R.id.edt_cveTarea2);
                    //Se crea el objeto Bundle
                    Bundle bundle = new Bundle();
                    //Se inserta el código en el objeto bundle
                    bundle.putString("cveTarea",edtCveTarea.getText().toString());
                    //Se crea un objeto bundle para iniciar la actividad
                    Intent intEditTarea = new Intent(getApplicationContext(), EditarTarea.class);
                    intEditTarea.putExtras(bundle);
                    startActivity(intEditTarea);
                }
            });
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}/*End*/